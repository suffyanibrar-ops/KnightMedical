# Deployment guide — Knight Medical Billing

This is a **Next.js 16 (App Router)** application with Tailwind CSS 4, Drizzle ORM and PostgreSQL.
It builds and runs on any Node 22 host (Netlify, Vercel, Render, Railway, Fly.io, Google Cloud Run,
Google AI Studio's Node runtime, or a plain VPS).

---

## 0. The one rule that guarantees a working preview

The website **does not require a database to render**. All content (services, audiences, specialties,
guides, FAQs) ships with built-in fallback data. If `DATABASE_URL` is missing or unreachable:

- every public page still renders completely,
- the admin console shows a "connect a database" notice after sign-in,
- form submissions are still validated and owner emails are still attempted.

That means a fresh import can never show a blank page or "refused to connect" because of a missing
database credential.

---

## 1. Netlify (recommended)

1. Push this repository to GitHub, then in Netlify choose **Add new site → Import an existing project**.
2. Build settings are read from `netlify.toml`:
   - Build command: `npm run build`
   - Publish directory: `.next`
   - Plugin: `@netlify/plugin-nextjs` (installs automatically)
   - Node: 22 (`.nvmrc` + `build.environment`)
3. Add environment variables under **Site configuration → Environment variables**:
   - `DATABASE_URL` (optional but required for admin storage) — e.g. Netlify DB, Neon, Supabase, RDS.
     Use `?sslmode=require`; TLS is enabled automatically for non-local hosts.
   - Optional: `RESEND_API_KEY` + `MAIL_FROM`, or `SMTP_HOST`/`SMTP_USER`/`SMTP_PASS`.
   - Optional: `ADMIN_PASSWORD_HASH`, `ADMIN_SESSION_SECRET`, `ADMIN_EMAIL`.
4. Deploy. Then run the schema + seed **once** against your database from your machine:

   ```bash
   DATABASE_URL="postgresql://…" npx drizzle-kit push
   DATABASE_URL="postgresql://…" node --experimental-strip-types scripts/seed.mjs
   ```

5. Open `https://your-site.netlify.app/api/health` — expect
   `{"ok":true,"database":"connected"}` (or `"not-configured"` if you skipped the database).

**Do not** set the publish directory to `public` and **do not** enable static HTML export for the
main site: the admin console, form APIs and middleware need the server runtime.

---

## 2. Any other Node host (Vercel, Render, Railway, Cloud Run, AI Studio)

```
Install:        npm install
Build:          npm run build
Start:          npm run start -- -p $PORT
Node version:   22.x
```

Start the server on the port provided by the platform (`PORT`). Bind to `0.0.0.0` (Next.js does this
by default when `HOSTNAME` is unset). If a platform asks for an output directory, use `.next`.

For **Google AI Studio / other container sandboxes**, the same three commands work inside the
container; expose the port the sandbox expects (often `3000`) and keep the process in the foreground.

---

## 3. Admin console

- URL: `/admin` (redirects to `/admin/login`)
- Password: `Medical#213` — stored only as a peppered SHA-256 digest in `src/lib/admin-session.ts`,
  never in client bundles. Override with `ADMIN_PASSWORD_HASH`.
- Sessions: signed HttpOnly cookie, 8-hour expiry, verified in `src/middleware.ts`.
- Rate limiting: 5 attempts per 15 minutes per IP; all attempts are audit-logged.
- Pages: overview, submissions (with status pipeline, search, CSV export), email outbox (retry +
  test email), subscribers, ROI estimates.

---

## 4. Email notifications

Every submission is written to the `email_outbox` table and sent to `ADMIN_EMAIL`
(default `admin@knightmedicalbilling.com`) through the first configured channel:

1. **Resend** — `RESEND_API_KEY` (plus verified `MAIL_FROM` domain)
2. **SMTP** — `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`
3. **FormSubmit relay** — `ENABLE_FORM_SUBMIT_RELAY=1` (no API key; requires a one-time activation
   click sent to the owner inbox)

Configure a channel, open **Admin → Email delivery → Send test email** to confirm, then
**Retry queued** to deliver anything captured before the channel existed. Without a channel,
notifications stay queued in the admin panel — nothing is lost.

---

## 5. Troubleshooting

| Symptom | Fix |
| --- | --- |
| "Refused to connect" / blank preview | The server process is not running. Re-run `npm run build && npm run start`; confirm the port matches the platform's `PORT`. Check `/api/health`. |
| Build fails on `DATABASE_URL is required` | No longer possible — the database is optional and lazily initialised. |
| Admin dashboard asks to connect a database | Expected in fallback mode. Set `DATABASE_URL` and redeploy. |
| Tables missing (`relation does not exist`) | Run `npx drizzle-kit push` against the production database. |
| Emails queued, never sent | No email channel configured. Add `RESEND_API_KEY` or SMTP credentials, then retry from the admin panel. |
| Images not optimising on a static host | Hosts that do not support Next Image Optimizer will still serve images; add `images.unoptimized: true` in `next.config.ts` if your host requires it. |

---

## 6. Security checklist before going live

- [ ] `netlify.toml` / host has HTTPS (automatic on Netlify).
- [ ] `ADMIN_PASSWORD_HASH` rotated from the default (generate a new peppered digest).
- [ ] `ADMIN_SESSION_SECRET` set to a long random value.
- [ ] Database uses TLS and a least-privilege role.
- [ ] `/admin` and `/api/` blocked in `robots.txt` (already configured) and not indexed.
- [ ] `/api/health` monitored.
- [ ] Security headers verified (CSP, HSTS, X-Frame-Options, Permissions-Policy in `next.config.ts`).
- [ ] Dependency advisories reviewed on your release cadence (`npm audit --omit=dev`).
