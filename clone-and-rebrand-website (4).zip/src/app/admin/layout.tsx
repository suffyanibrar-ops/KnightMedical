import type { Metadata } from "next";
import type { ReactNode } from "react";
import { AdminShell } from "@/components/admin/admin-shell";
import { isAdminAuthenticated } from "@/lib/auth";
import { isDatabaseConfigured } from "@/db";
import { OWNER_EMAIL } from "@/lib/email";
import { logoutAction } from "./actions";

export const metadata: Metadata = {
  title: "Admin Console",
  robots: { index: false, follow: false, nocache: true, googleBot: { index: false, follow: false } },
};

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const authenticated = await isAdminAuthenticated();

  // The sign-in screen renders without the console chrome. Every admin page
  // performs its own session check as well, so a host without middleware
  // support can never expose submissions.
  if (!authenticated) return <>{children}</>;

  if (!isDatabaseConfigured()) {
    return (
      <div className="grid min-h-screen place-items-center bg-mist-50 px-4 py-16">
        <div className="w-full max-w-lg rounded-3xl border border-mist-200 bg-white p-7 shadow-soft">
          <p className="text-[0.6rem] font-extrabold uppercase tracking-[0.2em] text-brand-700">Admin console</p>
          <h1 className="mt-2 text-2xl font-extrabold tracking-tight text-ink-950">Connect a database to store submissions</h1>
          <p className="mt-2 text-[0.88rem] leading-relaxed text-ink-600/80">
            The website is running in fallback mode, so all public pages work. To capture form submissions in this console, add a
            <code className="mx-1 rounded bg-mist-100 px-1.5 py-0.5 text-[0.78rem] font-bold text-ink-900">DATABASE_URL</code>
            environment variable (Postgres) and redeploy.
          </p>
          <ol className="mt-4 space-y-2 text-[0.82rem] text-ink-700">
            {[
              "Create a Postgres database (Netlify DB, Neon, Supabase, RDS…).",
              "Set DATABASE_URL in your hosting provider's environment variables.",
              "Run the schema push and content seed once: npx drizzle-kit push && node --experimental-strip-types scripts/seed.mjs.",
              "Redeploy, then reload this page.",
            ].map((item, index) => (
              <li key={item} className="flex gap-2.5">
                <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-brand-50 text-[0.6rem] font-extrabold text-brand-700">{index + 1}</span>
                {item}
              </li>
            ))}
          </ol>
          <p className="mt-4 rounded-xl bg-mist-50 px-3 py-2.5 text-[0.74rem] text-ink-600/70">
            Without a database, form submissions are still validated and owner email notifications are still queued and sent.
          </p>
        </div>
      </div>
    );
  }

  const logout = (
    <form action={logoutAction}>
      <button type="submit" className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-white/10 px-3 py-2 text-[0.7rem] font-bold text-white/80 transition-colors hover:bg-rose-500/80 hover:text-white">
        Sign out
      </button>
    </form>
  );

  return (
    <AdminShell email={OWNER_EMAIL} logout={logout}>
      {children}
    </AdminShell>
  );
}
