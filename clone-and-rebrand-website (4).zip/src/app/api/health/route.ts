import { NextResponse } from "next/server";
import { pingDatabase } from "@/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const database = await pingDatabase();
  return NextResponse.json({
    ok: true,
    service: "knight-medical-billing",
    database: database.configured ? (database.ok ? "connected" : "unavailable") : "not-configured",
    fallbackContent: !database.ok,
    timestamp: new Date().toISOString(),
  });
}
